# Your first week

1. Collect your badge.
2. Read the [quality manual](../README.md).
3. Meet your line manager.

![Office map](images/map.png)

| Day | Activity |
| --- | --- |
| 1 | Welcome |
| 2 | Systems training |

See also [old wiki](../missing.md).
